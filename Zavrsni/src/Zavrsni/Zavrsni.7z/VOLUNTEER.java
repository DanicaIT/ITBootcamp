package Zavrsni;

import org.openqa.selenium.WebDriver;

public class VOLUNTEER {
	
	static WebDriver driver;
	
	 public  VOLUNTEER(WebDriver driver) {
		this.driver = driver;
	}

}
